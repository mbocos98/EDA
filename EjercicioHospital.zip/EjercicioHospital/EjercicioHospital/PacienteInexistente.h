#pragma once
class PacienteInexistente {

};