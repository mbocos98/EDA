#pragma once
#include "DiccionarioHash.h"
#include "cola.h"
#include "Error.h"
#include <iostream>
using namespace std;

class PacienteDuplicado {};
class PacienteInexistente {};
class NoHayPacientes {};

class GestionAdmisiones {
public:
	GestionAdmisiones(){
		crea();
	}
	void crea() {
		leves = Cola<Paciente>();
		normales = Cola<Paciente>();
		graves = Cola<Paciente>();
		_dic = DiccionarioHash<unsigned int, Paciente>();
	}
	void an_paciente(unsigned int codigo, string nombre, int edad, string sintomas, string gravedad) {
		if (_dic.contiene(codigo)) {
			throw PacienteDuplicado();
		}
		else {
			Paciente p;
			p.id = codigo;
			p.nombre = nombre;
			p.edad = edad;
			p.sintomas = sintomas;
			p.gravedad = gravedad;
			
			if (gravedad == "leve") {
				leves.pon(p);
			}

			if (gravedad == "normal") {
				normales.pon(p);
			}

			if (gravedad == "grave") {
				graves.pon(p);
			}
			_dic.inserta(codigo, p);
		}
	}
	void info_paciente(unsigned int codigo, string &nombre, int &edad, string &sintomas) {
		if (!_dic.contiene(codigo)) {
			throw PacienteInexistente();
		}
		else {
			Paciente p = _dic.valorPara(codigo);
			nombre = p.nombre;
			edad = p.edad;
			sintomas = p.sintomas;
		}
	}

	void siguiente(unsigned int &codigo, string &gravedad) {
		if (!graves.esVacia()) {
			Paciente p = graves.primero();
			codigo = p.id;
			gravedad = "grave";
			graves.quita();
		}
		else if (!normales.esVacia()) {
			Paciente p = normales.primero();
			codigo = p.id;
			gravedad = "normal";
			normales.quita();
		}
		else if (!leves.esVacia()) {
			Paciente p = leves.primero();
			codigo = p.id;
			gravedad = "leve";
			leves.quita();
		}
		else {
			throw NoHayPacientes();
		}
	}

	bool hay_pacientes() {
		return !leves.esVacia() || !normales.esVacia() || !graves.esVacia();
	}
	void elimina(unsigned int codigo) {
		Cola<Paciente> *colaAux;
		if (_dic.contiene(codigo)) {
			Paciente p = _dic.valorPara(codigo);
			if (p.gravedad == "leve") {
				colaAux = &leves;
			}
			else if (p.gravedad == "normal") {
				colaAux = &normales;
			}
			else if (p.gravedad == "grave") {
				colaAux = &graves;
			}
			Paciente stop = colaAux->primero();
			colaAux->quita();
			colaAux->pon(stop);
			while(stop.id != colaAux->primero().id) {
				Paciente aux = colaAux->primero();
				colaAux->quita();
				if (aux.id != codigo) {
					colaAux->pon(aux);
				}
			}
			_dic.borra(codigo);
		}
	}


private:
	typedef struct {
		unsigned int id;
		int edad;
		string nombre;
		string sintomas;
		string gravedad;
	}Paciente;
	Cola<Paciente> leves;
	Cola<Paciente> normales;
	Cola<Paciente> graves;
	DiccionarioHash<unsigned int, Paciente> _dic;
};