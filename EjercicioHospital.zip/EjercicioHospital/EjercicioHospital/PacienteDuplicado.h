#pragma once
class PacienteDuplicado {

};