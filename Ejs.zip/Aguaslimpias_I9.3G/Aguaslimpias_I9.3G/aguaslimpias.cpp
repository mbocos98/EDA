#include "Arbin.h"
#include <iostream>
using namespace std;
Arbin<int> readTree(istream& in) {
	int n;
	in >> n;
	switch (n) {
		case -1: return Arbin<int>();
		default: {
			Arbin<int> iz = readTree(in);
			Arbin<int> dr = readTree(in);
			return Arbin<int>(iz, n, dr);
		}
	}
}
int tramosNavegables(const Arbin<int> &myArbin, int &tramosFinales) {
	if (myArbin.esVacio()) return 0;
	else if (myArbin.hijoIz().esVacio() && myArbin.hijoDr().esVacio()) return 1;
	int caudalIzq = tramosNavegables(myArbin.hijoIz(), tramosFinales);
	int caudalDer = tramosNavegables(myArbin.hijoDr(), tramosFinales);

	if (caudalIzq >= 3) tramosFinales++;
	if (caudalDer >= 3) tramosFinales++;
	int caudal = caudalIzq + caudalDer - myArbin.raiz();
	if (caudal < 0) caudal = 0;
	return caudal;
}
void solveCase() {
	Arbin<int> myArbin = readTree(cin);
	int tramosFinales = 0;
	int caudalTotal = tramosNavegables(myArbin, tramosFinales);
	cout << tramosFinales << endl;
}
int main() {
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		solveCase();
	}
	return 0;
}