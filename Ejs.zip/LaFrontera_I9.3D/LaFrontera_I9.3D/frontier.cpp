#include <iostream>
#include "Arbin.h"
using namespace std;
Arbin<int> readTree(istream& in) {
	int n;
	in >> n;
	switch (n) {
	case -1 : return Arbin<int>();
	default: {
		Arbin<int> iz = readTree(in);
		Arbin<int> dr = readTree(in);
		return Arbin<int>(iz, n, dr);
		}
	}
}
void frontier(const Arbin<int> &myArbin) {
	if (myArbin.esVacio()) {

	}
	else {
		if (myArbin.hijoIz().esVacio() && myArbin.hijoDr().esVacio()) cout << myArbin.raiz() << " ";
		frontier(myArbin.hijoIz());
		frontier(myArbin.hijoDr());
	}
}
void solveCase(){
	Arbin<int> myArbin = readTree(cin);
	frontier(myArbin);
	cout << endl;
}
int main() {
	int x;
	cin >> x;
	for (int i = 0; i < x; i++) {
		solveCase();
	}
	system("pause");
	return 0;
}