#include "Arbin.h"
#include <iostream>
#include <algorithm>
using namespace std;
Arbin<int> readTree(istream& in) {
	int n;
	in >> n;
	switch (n) {
	case -1: return Arbin<int>();
	default: {
		Arbin<int> iz = readTree(in);
		Arbin<int> dr = readTree(in);
		return Arbin<int>(iz, n, dr);
		}
	}
}
bool esPrimo(int num) {
	if (num < 0) num = num * (-1);
	int div = 0;
	for(int i = 1; i <= num; i++) {
		if (num % i == 0) {
			div++;
		}
	}
	if (div != 2) {
		return false;
	}
	else {
		return true;
	}
}
void multiploAccesible(const Arbin<int> &myArbin, int altura, int &multiplo, int &alturaFinal) {
	if (!myArbin.esVacio()) {
		altura++;
		if (!esPrimo(myArbin.raiz())) 
			if (myArbin.raiz() % 7 == 0) {
				if (multiplo == -1 || altura < alturaFinal) {
					multiplo = myArbin.raiz();
					alturaFinal = altura;
					return;
				}
			}
			else {
				multiploAccesible(myArbin.hijoIz(), altura, multiplo, alturaFinal);
				multiploAccesible(myArbin.hijoDr(), altura, multiplo, alturaFinal);
			}
		}

	}
void solveCase() {
	Arbin<int> myArbin = readTree(cin);
	int multiplo = -1;
	int alturaFinal = 0;
	multiploAccesible(myArbin, 0, multiplo, alturaFinal);
	if (multiplo != -1) {
		cout << multiplo <<  " " << alturaFinal << endl;
	}
	else cout << "NO HAY" << endl;
	
}
int main() {
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		solveCase();
	}
	return 0;
}