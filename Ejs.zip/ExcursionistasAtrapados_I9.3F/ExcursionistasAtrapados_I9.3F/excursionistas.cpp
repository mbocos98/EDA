#include <iostream>
#include "Arbin.h"
using namespace std;
void excursionistas(const Arbin<int> &myArbin, int &suma, int &grupos) {
	if(!myArbin.esVacio()){
		if (myArbin.hijoIz().esVacio() && myArbin.hijoDr().esVacio()) {
			if (myArbin.raiz() != 0) {
				suma = suma + myArbin.raiz();
				grupos++;
			}
			return;
		}
		int gruposIzq = 0, gruposDer = 0, sumaIzq = 0, sumaDer = 0;
		excursionistas(myArbin.hijoIz(), sumaIzq, gruposIzq);
		excursionistas(myArbin.hijoDr(), sumaDer, gruposDer);
		if (gruposIzq == 0 && gruposDer == 0) {
			 if(myArbin.raiz() != 0){
				 suma = suma + myArbin.raiz();
				grupos++;
			 }
			return;
		}
		grupos = grupos + gruposIzq + gruposDer;
		suma = suma + myArbin.raiz();


		if (sumaIzq >= sumaDer) suma = suma + sumaIzq;
		else suma = suma + sumaDer;
	}
	
}
Arbin<int> readTree(istream& in) {
	int n;
	in >> n;
	switch (n) {
		case -1: return Arbin<int>();
		default: {
			Arbin<int> iz = readTree(in);
			Arbin<int> dr = readTree(in);
			return Arbin<int>(iz, n, dr);
		}
	}
}
void solveCase() {
	Arbin<int> myArbin = readTree(cin);
	int suma = 0;
	int grupos = 0;
	excursionistas(myArbin, suma, grupos);
	cout << grupos << " " << suma << endl;
}
int main() {
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		solveCase();
	}
	return 0;
}