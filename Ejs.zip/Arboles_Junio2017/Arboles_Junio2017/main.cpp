#include "Arbin.h"
#include <iostream>
using namespace std;
//O(numero de nodos del arbol)
void numNodos(const Arbin<int> myArbin, unsigned int k, int &numHojas, int &profActual) {
	if (!myArbin.esVacio()) {
		if (myArbin.hijoIz().esVacio() && myArbin.hijoDr().esVacio()) {
			if (profActual >= k) numHojas++;
		}
		else {
			profActual++;
			numNodos(myArbin.hijoIz(), k, numHojas, profActual);
			numNodos(myArbin.hijoDr(), k, numHojas, profActual);
		}
	}
}
Arbin<int> readTree(istream& in) {
	int n;
	in >> n;
	switch (n) {
	case -1: return Arbin<int>();
	default: {
		Arbin<int> iz = readTree(in);
		Arbin<int> dr = readTree(in);
		return Arbin<int>(iz, n, dr);
	}
	}
}
void solveCase() {
	int numHojas = 0;
	int profActual = 0;
	unsigned int k;
	cin >> k;
	Arbin<int> arbol = readTree(cin);
	numNodos(arbol, k, numHojas, profActual);
	cout << numHojas << endl;
}
int main() {
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		solveCase();
	}
	return 0;
}