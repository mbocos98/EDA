#include "Arbin.h"
#include <iostream>
#include <algorithm>
using namespace std;
Arbin<char> readTree(istream& in) {
	char c;
	in >> c;
	switch (c) {
		case '.': return Arbin<char>();
		default: {
			Arbin<char> iz = readTree(in);
			Arbin<char> dr = readTree(in);
			return Arbin<char>(iz, c, dr);
		}
	}
}
int nodosHojasYAltura(const Arbin<char> myArbin, int &nodos, int &hojas) {
	if (!myArbin.esVacio()) {
		if (myArbin.raiz() == '*') nodos++;
		if (myArbin.hijoIz().esVacio() && myArbin.hijoDr().esVacio()) hojas++;
		int alturaIzq = nodosHojasYAltura(myArbin.hijoIz(), nodos, hojas);
		int alturaDer = nodosHojasYAltura(myArbin.hijoDr(), nodos, hojas);
		return 1 + max(alturaIzq, alturaDer);
	}
	else return 0;
}
void solveCase() {
	Arbin<char> arbin = readTree(cin);
	int nodos = 0, hojas = 0;
	int altura = nodosHojasYAltura(arbin, nodos, hojas);
	cout << nodos << " " << hojas << " " << altura << endl;
}
int main() {
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		solveCase();
	}
	return 0;
}