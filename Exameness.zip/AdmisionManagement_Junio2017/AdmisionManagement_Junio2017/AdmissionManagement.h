#pragma once
#include "HashMap.h"
#include "Queue.h"
#include <iostream>
using namespace std;
struct Paciente {
	string id;
	string name;
	int age;
	string symptoms;
};
class PacienteDuplicado {};
class PacienteInexistente {};
class NoHayPacientes {};
class AdmissionManagement {
public:
	void create() {
		patientsById = HashMap<string, Paciente>();
		patientsWaiting = Queue<Paciente>();
	}
	//Cost: O(1) because it's a HashMap
	void addPatient(string id, string name, int age, string symptoms) {
		if (patientsById.contains(id)) {
			throw PacienteDuplicado();
		}
		Paciente aux;
		aux.name = name;
		aux.age = age;
		aux.symptoms = symptoms;
		patientsById.insert(id, aux);
		patientsWaiting.push_back(aux);
	}
	//Cost: O(1)
	void patientInfo(string id, string &name, string &age, string &symptoms) {
		if (patientsById.contains(id)) {
			Paciente aux = patientsById.at(id);
			name = aux.name;
			age = aux.age;
			symptoms = aux.symptoms;
		}
		else throw PacienteInexistente();
	}
	//Cost: O(1)
	void next(string &code) {
		if (!patientsWaiting.empty()) {
			Paciente aux = patientsWaiting.front();
			patientsWaiting.pop_front();
			code = aux.id;
		}
		else {
			throw NoHayPacientes();
		}
	}
	//Cost: O(1)
	bool morePatients() {
		return !patientsWaiting.empty();
	}
	//Cost: O
	void erase(string code) {
		if (patientsById.contains(code)) {
			Paciente stop = patientsWaiting.front();
			patientsWaiting.push_back(stop);
			patientsWaiting.pop_front();
			while (stop.id != patientsWaiting.front().id) {
				Paciente aux = patientsWaiting.front();
				patientsWaiting.pop_front();
				if (aux.id != code) {
					patientsWaiting.pop_front();
				}
			}
			patientsById.erase(code);
		}
	}

private:
	HashMap<string, Paciente> patientsById;
	Queue<Paciente> patientsWaiting;
};