#include <iostream>
#include "Arbin.h"
using namespace std;
void helpTime(const Arbin<char> &a, int tiempoActual, int &tiempoTotal) {
	if (a.esVacio()) {}
	else {
		if (a.raiz == 'X') {
			tiempoActual = tiempoActual * 2;
			tiempoTotal += tiempoActual;
			return;
		}
		else {
			helpTime(a.hijoIz, tiempoActual + 1, tiempoTotal);
			helpTime(a.hijoDr, tiempoActual + 1, tiempoTotal);
		}
	}
	
}
void solveCase() {
	//Arbin<char> arbol = readTree(cin);
}
int main() {
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		solveCase();
	}
}