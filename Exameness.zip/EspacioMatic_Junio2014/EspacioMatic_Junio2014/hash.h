/**
 @file hash.h
 
 Declaraci�n e implementaci�n de funciones de codificaci�n para
 tipos b�sicos y funci�n gen�rica que conf�a en la existencia
 del m�todo m�todo hash de las clases.
 
 Estructura de Datos y Algoritmos
 Facultad de Inform�tica
 Universidad Complutense de Madrid
 
 (c) Antonio S�nchez Ruiz-Granados, 2012. A�adidas algunas funciones Jose Luis Sierra, 2016
 */

#ifndef __HASH_H
#define __HASH_H

#include <string>

// ----------------------------------------------------
//
// Funciones hash para distintos tipos de datos b�sicos
//
// ----------------------------------------------------


unsigned int h(unsigned int clave);

unsigned int h(int clave);

unsigned int h(short clave);

unsigned int h(unsigned short clave);

unsigned int h(long clave);

unsigned int h(unsigned long clave);

unsigned int h(char clave);

// Fowler/Noll/Vo (FNV) -- adaptada de http://bretmulvey.com/hash/6.html 
unsigned int h(std::string clave);

/**
 * Funci�n hash gen�rica para clases que implementen un
 * m�todo publico hashcode.
 */
//template<class C>
//unsigned int h(const C &clave) {
//	return clave.hashcode();
//}


#endif // __HASH_H
