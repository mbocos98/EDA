#pragma once
#include <iostream>
using namespace std;
#include "DiccionarioHash.h"
#include "diccionario.h"
struct Nave {
	Diccionario<string, int> modulos;
};
class IdExistente {};
class EspacioMatic {
public:

	void nuevaNave(int id) {
		if (navesPorId.contiene(id)) {
			throw IdExistente();
		}
		Nave nave;
		navesPorId.inserta(id, nave);
	}
	void equipaNave(int id, string modulo, int nivel) {
		if (navesPorId.contiene(id)) {
			Nave nave = navesPorId.valorPara(id);
			if (nave.modulos.contiene(modulo)) {
				nave.modulos.inserta(modulo, nave.modulos.valorPara(modulo) + nivel);
			}
			else {
				nave.modulos.inserta(modulo, nivel);
			}
		}
	}
	bool estropeaNave(int id, string modulo) {
		if (navesPorId.contiene(id)) {
			Nave nave = navesPorId.valorPara(id);
			if (nave.modulos.contiene(modulo) && nave.modulos.valorPara(modulo) > 0) {
				nave.modulos.inserta(modulo, nave.modulos.valorPara(modulo) - 1);
			}
			else return false;
		}
		else return false;

	}
	Lista<int> navesDefectuosas() { 
		bool tieneModulosEstropeados = false;
		Lista<int> defectuosas;
		for (DiccionarioHash<int, Nave> ::ConstIterator it = navesPorId.cbegin(); it != navesPorId.cend; it.next()) {
			for (Diccionario <string, int> ::ConstIterator it2 = it.valor().modulos.cbegin(); it2 != it.valor().modulos.cend(); it2.next()) {
				if (it2.valor == 0) {
					tieneModulosEstropeados = true;
				}
			}
			if (tieneModulosEstropeados) defectuosas.pon_final(it.clave);
		}
	}
	Lista<string> modulosNave(int id){
		Lista<string> modulos;
		if (navesPorId.contiene(id)) {
			Nave nave = navesPorId.valorPara(id);
			for (Diccionario <string, int> ::ConstIterator it = nave.modulos.cbegin(); it != nave.modulos.cend(); it.next()) {
				modulos.pon_final(it.clave);
			}
		}
		return modulos;
	}
private:

	DiccionarioHash<int, Nave> navesPorId;
	Lista<int> defectuosas;
};