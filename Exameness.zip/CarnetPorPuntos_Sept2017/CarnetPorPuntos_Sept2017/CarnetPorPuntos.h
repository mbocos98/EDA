#pragma once
#include <iostream>
#include "HashMap.h"
using namespace std;

class ConductorDuplicado {};	
class ConductorInexistente {};  //Excepciones
class PuntosNoValidos {};

class CarnetPorPuntos {
public:
	//Complexity: O(1)
	void nuevo(string dni) {
		if (conductores.contains(dni)) {
			throw ConductorDuplicado();
		}
		else {
			conductores.insert(dni, 15);
		}
	}
	//Complexity: O(1)
	void quitar(string dni, int puntos) {
		if (!conductores.contains(dni)) {
			throw ConductorInexistente();
		}
		else {
			if (conductores.at(dni) < puntos) conductores.insert(dni, 0);
			else conductores.insert(dni, conductores.at(dni) - puntos);
		}
	}
	//Complexity: O(1)
	int consultar(string dni) {
		if (conductores.contains(dni)) {
			return conductores.at(dni);
		}
		else {
			throw ConductorInexistente();
		}
	}
	//Complexity: O(numero de dnis)
	int cuantos_con_puntos(int puntos) {
		int numConductores = 0;
		if (puntos < 0 || puntos > 15) throw PuntosNoValidos();
		else {
			for (HashMap<string, int> :: ConstIterator it = conductores.cbegin(); it != conductores.cend(); it.next()) {
				if (it.value() == puntos) numConductores++;
			}
		}
		return numConductores;
	}

private:
	HashMap<string, int> conductores;
};