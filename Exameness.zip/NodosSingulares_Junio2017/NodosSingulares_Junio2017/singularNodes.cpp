#include "Arbin.h"
#include <iostream>
#include <string>
using namespace std;
Arbin<int> readTree(istream& in) {
	int c;
	in >> c;
	switch (c) {
	case -9 : return Arbin<int>();
	default:
		Arbin<int> iz = readTree(in);
		Arbin<int> dr = readTree(in);
		return Arbin<int>(iz, c, dr);
	}

}
void nodosSingulares(const Arbin<int> myArbin, int &asc, int &desc, int &singulares) {
	if (myArbin.esVacio()) {

	}
	else {
		if (myArbin.hijoIz().esVacio() && myArbin.hijoDr().esVacio()) {
			if (asc == 0) singulares++;
			desc = myArbin.raiz();
		}
		else {
			int singularesIzquierda = 0, singularesDerecha = 0;
			int descIzq = 0, descDer = 0;
			asc = asc + myArbin.raiz();
			nodosSingulares(myArbin.hijoIz(), asc, descIzq, singularesIzquierda);
			nodosSingulares(myArbin.hijoDr(), asc, descDer, singularesDerecha);
			if (asc == desc) {
				singulares++;
			}
			desc = descIzq + descDer + myArbin.raiz();
			
		}
	}
}
int main() {
	Arbin<int> arbol;
	while (true) {
		arbol = readTree(cin);
		int asc = 0, desc = 0, singulares = 0;
		nodosSingulares(arbol, asc, desc, singulares);
		cout << singulares << endl;
	}
	return 0;
}
