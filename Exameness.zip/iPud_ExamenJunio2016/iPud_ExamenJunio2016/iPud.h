#pragma once
#include <iostream>
#include "HashMap.h"
#include "List.h"
using namespace std;
//DO NOT USE TYPEDEF STRUCT, USE STRUCT INSTEAD
struct SongInfo{
	string artist;
	int duration;
	bool inPlaylist; //indica si esta en la lista de reproduccion
	bool played; //indica si esta en la lista de reproducidas
};
class ESameNameSong {};
class ESongNotInIPud {};
class EEmptyList {};
class iPud {
public:
	void create() {

	}
	void addSong(string song, string artist, int duration) {
		if (songs.contains(song)) {
			throw ESameNameSong();
		}
		SongInfo info;
		info.artist = artist;
		info.duration = duration;
		info.inPlaylist = info.played = false;
		songs.insert(song, info);
		duration = duration + songs[song].duration;
	}
	void addToPlaylist(string song) {
		if (songs.contains(song)) {
			throw ESongNotInIPud();
		}
		if (songs[song].inPlaylist) {
			playlist.push_back(song);
			songs[song].inPlaylist = true;
		}
	}
	void deleteSong(string song) {
		if (songs.contains(song)) {
			SongInfo &info = songs[song];
			if (!info.inPlaylist) {
				eraseFromList(playlist, song);
				duration = duration - songs[song].duration;
			}
			songs.erase(song);
		}
	}
	
	void play() {
		List<string>::Iterator it = playlist.begin();
		if (it == playlist.end()) return;
		played.push_front(it.elem()); //*it
		if (songs[it.elem()].played) {
			eraseFromList(played, it.elem());
		}
		playlist.erase(it);
	} 
	string current() {
		List<string>::Iterator it = playlist.begin();
		if (it == playlist.end()) {
			throw ESongNotInIPud();
		}
		return it.elem();
	}
	int totalTime() {
		return duration;
	}
	List<string> recent(int n) {
		List<string> result;
		int c = 0;
		for (List<string> ::ConstIterator it = played.cbegin(); c < n && it != played.cend(); it++, c++) {
			result.push_back(it.elem());
		}
		return result;
	}
private:
	void eraseFromList(List<string> &l, string item) {//auxiliary method to call whenever we want to erase something from a list
		for (List<string> ::Iterator it = l.begin(); it != l.end(); it.next()){
			if (it.elem() == item) {
				l.erase(it);
				return;
			}
		})
	}
	HashMap<string, SongInfo> songs;
	List<string> playlist;
	List<string> played;
	int duration;
};